<?php
include('includes/dbconnection.php');

if (isset($_POST['approve'])) {
    $ID = $_POST['ID'];
    // Update the approval_status for the company with $companyID
    $updateQuery = "UPDATE tblcompany SET approval_status = 'Approved' WHERE ID = $ID";
    mysqli_query($con, $updateQuery);
} elseif (isset($_POST['deny'])) {
    $ID = $_POST['ID'];
    // Update the approval_status for the company with $companyID
    $updateQuery = "UPDATE tblcompany SET approval_status = 'Denied' WHERE ID = $ID";
    mysqli_query($con, $updateQuery);
}

// Redirect back to the page where the approval was made.
header('Location: company-approval.php');
?>
